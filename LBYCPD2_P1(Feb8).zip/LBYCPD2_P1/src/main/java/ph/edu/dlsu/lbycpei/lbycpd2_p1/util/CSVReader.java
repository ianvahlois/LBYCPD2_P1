package ph.edu.dlsu.lbycpei.lbycpd2_p1.util;

import ph.edu.dlsu.lbycpei.lbycpd2_p1.model.PayrollRecord;

import java.io.*;
import java.util.*;

/**
 * Reads payroll CSV with columns: employeeId, name, hoursWorked, hourlyRate [, client]
 * Header row is skipped. Client is optional (5th column).
 */
public class CSVReader {

    public static List<PayrollRecord> readCSV(String path) {
        List<PayrollRecord> records = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            br.readLine(); // skip header

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] data = parseCsvLine(line);
                if (data.length < 4) continue;

                String employeeId = data[0].trim();
                String name = data[1].trim();
                double hours = Double.parseDouble(data[2].trim());
                double rate = Double.parseDouble(data[3].trim());
                String client = data.length > 4 ? data[4].trim() : "";

                records.add(new PayrollRecord(employeeId, name, client, hours, rate, null, null));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return records;
    }

    /** Simple CSV line parse: handles quoted fields with commas. */
    private static String[] parseCsvLine(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                out.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        out.add(cur.toString());
        return out.toArray(new String[0]);
    }
}
